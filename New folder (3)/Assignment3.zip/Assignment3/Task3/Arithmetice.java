import java.util.Scanner;

public class Arithmetice extends Throwable {

    public static void main(String[] args) {
        int openAccount;
        Scanner scan = new Scanner(System.in);
        Arithmetice obj = new Arithmetice();
        try {
            System.out.println("Enter Amount for Account Opening");
            int amount = scan.nextInt();
            if (amount <= 0) {
                System.out.println("Amount should must be grater than 0");
            }
        }
        catch(ArithmeticException e ){
            System.out.println("Amount can't be less than zero");
        }
    }
}
