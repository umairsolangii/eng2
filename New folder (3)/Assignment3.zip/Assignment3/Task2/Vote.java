package VoteCastingMachine;

import javax.swing.tree.ExpandVetoException;

public class Vote {
    private int age;


    //Getter
    public int getAge(){
        return this.age;
    }

    //Setter
    public void setAge(int age){
        this.age = age;

    }
}
