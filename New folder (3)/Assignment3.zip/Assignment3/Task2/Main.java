package VoteCastingMachine;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Vote obj = new Vote();
        System.out.println("Enter Your Age");
        int a = scan.nextInt();
        obj.setAge(a);

       System.out.println("Your Age is: " + obj.getAge());
       if(obj.getAge() >= 18){
           System.out.println("You Can Cast a Vote");
       }else{
           System.out.println("You Can't Cast a vote");
       }
    }
}
