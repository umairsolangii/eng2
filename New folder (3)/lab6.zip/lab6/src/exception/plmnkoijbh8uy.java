package exception;

public class plmnkoijbh8uy {
}
